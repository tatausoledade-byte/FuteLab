# FuteLab — Next.js Starter\n\nThis project is a minimal Next.js site for FuteLab. To run locally:\n\n```
npm install
npm run dev
```\n\nTo deploy: push to GitHub and import the repository in Vercel (recommended).\n\nWhatsApp: +55 71 99105-6272\nSlogan: "Aqui, treino inteligente vira resultado."