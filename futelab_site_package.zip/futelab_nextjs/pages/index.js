import Head from 'next/head'
import Link from 'next/link'

export default function Home() {
  return (
    <div>
      <Head>
        <title>FuteLab — Aqui, treino inteligente vira resultado.</title>
        <meta name="description" content="FuteLab — Treinos de futevôlei com metodologia e performance."/>
        <link rel="icon" href="/logo.png" />
      </Head>

      <header className="header">
        <div className="container">
          <div className="brand">
            <img src="/logo.png" alt="FuteLab" className="logo" />
            <div className="brand-text">
              <div className="brand-name">FuteLab</div>
              <div className="slogan">Aqui, treino inteligente vira resultado.</div>
            </div>
          </div>
          <nav className="nav">
            <Link href="/"><a>Início</a></Link>
            <Link href="/about"><a>Sobre</a></Link>
            <Link href="/plans"><a>Planos</a></Link>
            <Link href="/aluno"><a>Área do Aluno</a></Link>
            <a className="btn-whatsapp" href="https://wa.me/5517991056272?text=Ol%C3%A1!%20Quero%20agendar%20uma%20aula%20no%20FuteLab." target="_blank" rel="noreferrer">WhatsApp</a>
          </nav>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="container hero-inner">
            <div className="hero-copy">
              <h1>Aqui, treino inteligente vira resultado.</h1>
              <p className="lead">Metodologia, ciência e prática para elevar seu nível no futevôlei — treinos personalizados para quem quer competir ou melhorar o jogo.</p>
              <div className="hero-cta">
                <a className="btn primary" href="https://wa.me/5517991056272?text=Ol%C3%A1!%20Quero%20agendar%20uma%20aula%20no%20FuteLab." target="_blank" rel="noreferrer">Agende sua aula</a>
                <a className="btn outline" href="/plans">Planos e preços</a>
              </div>
            </div>
            <div className="hero-media">
              <img src="/hero.jpg" alt="Atleta FuteLab" />
            </div>
          </div>
        </section>

        <section id="sobre" className="section about">
          <div className="container about-grid">
            <div>
              <h2>Sobre o FuteLab</h2>
              <p>O FuteLab nasceu da união entre ciência e prática esportiva. Nossa metodologia une treinamento inteligente, performance e técnica para atletas que buscam evolução real dentro da areia.</p>
              <ul className="features">
                <li><strong>Metodologia</strong><span>Treinos baseados em evidências e progressão.</span></li>
                <li><strong>Força</strong><span>Condicionamento específico para areia.</span></li>
                <li><strong>Performance</strong><span>Resultados mensuráveis ao longo do tempo.</span></li>
              </ul>
            </div>
            <div>
              <img src="/hero.jpg" alt="Treino FuteLab" className="rounded" />
            </div>
          </div>
        </section>

      </main>

      <footer className="site-footer">
        <div className="container footer-inner">
          <div className="footer-left">
            <img src="/logo.png" alt="FuteLab" className="logo-small" />
            <div>© FuteLab 2025</div>
          </div>
          <div className="footer-right">
            <a className="btn-whatsapp" href="https://wa.me/5517991056272?text=Ol%C3%A1!%20Quero%20agendar%20uma%20aula%20no%20FuteLab." target="_blank" rel="noreferrer">WhatsApp</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
